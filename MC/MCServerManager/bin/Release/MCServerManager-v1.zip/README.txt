#####################
# MC Server Manager #
#####################

v1.0
This is the first version so there are a lot of bugs. If you find something weird, report it!


Attention!
I'm not affiliated, associated, authorized, endorsed by, or in any way officially connected with Mojang Studios
Minecraft isn't made by me
I made this program only to help people managing their servers.
This program uses the Mojang API to download the server files from their official site.

This program works thanks to Newtonsoft Json (not made by me).