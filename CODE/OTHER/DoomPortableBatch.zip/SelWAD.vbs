Dim gzf, wadf, Arg, objShell
On Error Resume Next
Set Arg = WScript.Arguments
gzf = Arg(0)
If Err.Number = 0 Then
Else
NotDragNdrop = MsgBox("Sorry, an error has occurred", vbExclamation, "Launcher")
WScript.Quit
End If

Set objShell = CreateObject("WScript.Shell")
Function GetFileDlgEx(sIniDir,sFilter,sTitle) 
Set oDlg = CreateObject("WScript.Shell").Exec("mshta.exe ""about:<object id=d classid=clsid:3050f4e1-98b5-11cf-bb82-00aa00bdce0b></object><script>moveTo(0,-9999);eval(new ActiveXObject('Scripting.FileSystemObject').GetStandardStream(0).Read("&Len(sIniDir)+Len(sFilter)+Len(sTitle)+41&"));function window.onload(){var p=/[^\0]*/;new ActiveXObject('Scripting.FileSystemObject').GetStandardStream(1).Write(p.exec(d.object.openfiledlg(iniDir,null,filter,title)));close();}</script><hta:application showintaskbar=yes icon='%SystemRoot%\explorer.exe'/>""") 
oDlg.StdIn.Write "var iniDir='" & sIniDir & "';var filter='" & sFilter & "';var title='" & sTitle & "';" 
GetFileDlgEx = oDlg.StdOut.ReadAll 
End Function

sFilter = "Doom WAD (*.wad)|*.wad|Doom PK3 (*.pk3)|*.pk3|"  
sTitle = "Select an IWAD"
wadf = GetFileDlgEx(Replace(sIniDir,"\","\\"),sFilter,sTitle)
if wadf = "" then
NotWADErr = MsgBox("Select an IWAD", vbExclamation, "Launcher")
WScript.Quit
else

MultiIP = InputBox("Do you want to play in multiplayer?" & vbNewLine & "If yes please write the IP of the host." & vbNewLine & "Else don't write anything.", "Launcher")
if Len(MultiIP) = 0 Then
objShell.Run chr(34) & gzf & chr(34) & " -iwad " & chr(34) & wadf & chr(34)
Else
MPort = InputBox("Write the port (leave blank to use the default one).", "Launcher")
if Len(MPort) = 0 Then
objShell.Run chr(34) & gzf & chr(34) & " -iwad " & chr(34) & wadf & chr(34) & " -join " & MultiIP
Else
objShell.Run chr(34) & gzf & chr(34) & " -iwad " & chr(34) & wadf & chr(34) & " -join " & MultiIP & " -port " & MPort
end if
end if
end if