@echo off
Title DOOMLauncher
Mode Con Cols=21 Lines=9
BG Cursor 0
IF EXIST "%PROGRAMFILES(X86)%" (SET gzdpath=%~dp0gzdoom64b\) ELSE (SET gzdpath=%~dp0gzdoom32b\)
if not exist "%gzdpath%" mkdir "%gzdpath%"
if not exist "%gzdpath%gzdoom_portable.ini" type nul >"%gzdpath%gzdoom_portable.ini"
if not exist "%~dp0WADS\" (mkdir "%~dp0WADS\" & echo The WAD files in this folder will work when selected on the menu. Valid ones: doom.wad, doom2.wad, plutonia.wad, tnt.wad, heretic.wad, hexen.wad >"%~dp0WADS\autoexec_wads.txt")
if not exist "%gzdpath%gzdoom.exe" GOTO MISSGZ

:1
SET selwad=doom
CLS
echo.
BG Print 04 "   (    DOOM    )\n"
echo    (  DOOM II   )
echo    (  PLUTONIA  )
echo    (    TNT     )
echo    (  HERETIC   )
echo    (   HEXEN    )
echo    (   OTHER    )
BG Kbd
IF %ERRORLEVEL%==328 (GOTO 1) ELSE IF %ERRORLEVEL%==336 (GOTO 2) ELSE IF %ERRORLEVEL%==13 (GOTO STGZY) ELSE (GOTO 1)
:2
SET selwad=doom2
CLS
echo.
echo    (    DOOM    )
BG Print 04 "   (  DOOM II   )\n"
echo    (  PLUTONIA  )
echo    (    TNT     )
echo    (  HERETIC   )
echo    (   HEXEN    )
echo    (   OTHER    )
BG Kbd
IF %ERRORLEVEL%==328 (GOTO 1) ELSE IF %ERRORLEVEL%==336 (GOTO 3) ELSE IF %ERRORLEVEL%==13 (GOTO STGZY) ELSE (GOTO 2)
:3
SET selwad=plutonia
CLS
echo.
echo    (    DOOM    )
echo    (  DOOM II   )
BG Print 04 "   (  PLUTONIA  )\n"
echo    (    TNT     )
echo    (  HERETIC   )
echo    (   HEXEN    )
echo    (   OTHER    )
BG Kbd
IF %ERRORLEVEL%==328 (GOTO 2) ELSE IF %ERRORLEVEL%==336 (GOTO 4) ELSE IF %ERRORLEVEL%==13 (GOTO STGZY) ELSE (GOTO 3)
:4
SET selwad=tnt
CLS
echo.
echo    (    DOOM    )
echo    (  DOOM II   )
echo    (  PLUTONIA  )
BG Print 04 "   (    TNT     )\n"
echo    (  HERETIC   )
echo    (   HEXEN    )
echo    (   OTHER    )
BG Kbd
IF %ERRORLEVEL%==328 (GOTO 3) ELSE IF %ERRORLEVEL%==336 (GOTO 5) ELSE IF %ERRORLEVEL%==13 (GOTO STGZY) ELSE (GOTO 4)
:5
SET selwad=heretic
CLS
echo.
echo    (    DOOM    )
echo    (  DOOM II   )
echo    (  PLUTONIA  )
echo    (    TNT     )
BG Print 04 "   (  HERETIC   )\n"
echo    (   HEXEN    )
echo    (   OTHER    )
BG Kbd
IF %ERRORLEVEL%==328 (GOTO 4) ELSE IF %ERRORLEVEL%==336 (GOTO 6) ELSE IF %ERRORLEVEL%==13 (GOTO STGZY) ELSE (GOTO 5)
:6
SET selwad=hexen
CLS
echo.
echo    (    DOOM    )
echo    (  DOOM II   )
echo    (  PLUTONIA  )
echo    (    TNT     )
echo    (  HERETIC   )
BG Print 04 "   (   HEXEN    )\n"
echo    (   OTHER    )
BG Kbd
IF %ERRORLEVEL%==328 (GOTO 5) ELSE IF %ERRORLEVEL%==336 (GOTO 7) ELSE IF %ERRORLEVEL%==13 (GOTO STGZY) ELSE (GOTO 6)
:7
SET selwad=other
CLS
echo.
echo    (    DOOM    )
echo    (  DOOM II   )
echo    (  PLUTONIA  )
echo    (    TNT     )
echo    (  HERETIC   )
echo    (   HEXEN    )
BG Print 04 "   (   OTHER    )\n"
BG Kbd
IF %ERRORLEVEL%==328 (GOTO 6) ELSE IF %ERRORLEVEL%==336 (GOTO 7) ELSE IF %ERRORLEVEL%==13 (GOTO STGZY) ELSE (GOTO 7)


:: Start GZDoom and select PWAD
:STGZY
CLS
echo Do you want to start the game with a PWAD?
echo.
BG Print 04 "      ( YES )\n"
echo       ( NO  )
BG Kbd
IF %ERRORLEVEL%==328 (GOTO STGZY) ELSE IF %ERRORLEVEL%==336 (GOTO STGZN) ELSE IF %ERRORLEVEL%==13 (GOTO STGZPWAD) ELSE (GOTO STGZY)
:STGZN
CLS
echo Do you want to start the game with a PWAD?
echo.
echo       ( YES )
BG Print 04 "      ( NO  )\n"
BG Kbd
IF %ERRORLEVEL%==328 (GOTO STGZY) ELSE IF %ERRORLEVEL%==336 (GOTO STGZN) ELSE IF %ERRORLEVEL%==13 (GOTO STGZD) ELSE (GOTO STGZN)
GOTO :EOF

:STGZPWAD
cd "%~dp0"
if %selwad%==other (
Start Custom.vbs "%gzdpath%gzdoom.exe"
) ELSE (
START SelPK3.vbs "%~dp0WADS\%selwad%.wad" "%gzdpath%gzdoom.exe" )
GOTO :EOF

:STGZD
if %selwad%==other (
cd "%~dp0"
Start SelWAD.vbs "%gzdpath%gzdoom.exe"
) ELSE (GOTO NOTOTH)

:NOTOTH
cd "%gzdpath%"
CLS
Mode Con Cols=32 Lines=9
SET /P MIP="Do you want to play multiplayer?If yes write the IP of the host.Else, leave the field blank.    >"
IF [%MIP%] == [] GOTO NOM
GOTO YESM
GOTO :EOF

:NOM
START gzdoom.exe -iwad "%~dp0WADS\%selwad%.wad"
GOTO :EOF

:YESM
Mode Con Cols=52 Lines=9
CLS
SET /P IMPORT="Write the port (Leave blank to use the default one) >"
IF [%IMPORT%] == [] GOTO DPORT
START gzdoom.exe -iwad "%~dp0WADS\%selwad%.wad" -join %MIP%
GOTO :EOF

:DPORT
START gzdoom.exe -iwad "%~dp0WADS\%selwad%.wad" -join %MIP% -port %IMPORT%
GOTO :EOF

:MISSGZ
CLS
Mode Con Cols=68 Lines=9
echo GZDoom is missing. Please, download it from www.zdoom.org/downloads and put it on %gzdpath%
pause
GOTO :EOF